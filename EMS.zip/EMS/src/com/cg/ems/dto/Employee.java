package com.cg.ems.dto;

public class Employee {
	private int EmpId;
	private String name;
	private double salary;
	private String designation;
	private String insuranceScheme;
	
	public int getEmpId() {
		return EmpId;
	}
	public void setEmpId(int empId) {
		EmpId = empId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String age) {
		this.designation = age;
	}
	public String getInsuranceScheme() {
		return insuranceScheme;
	}
	public void setInsuranceScheme(String insuranceScheme) {
		this.insuranceScheme = insuranceScheme;
	}
	//@Override
	/*public String toString() {
		return "Employee [EmpId=" + EmpId + ", name=" + name + ", salary="
				+ salary + ", designation=" + designation
				+ ", insuranceScheme=" + insuranceScheme + "]";
	}*/
	
	
	

}
