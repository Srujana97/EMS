package com.cg.ems.dao;

import java.util.ArrayList;
import com.cg.ems.dto.Employee;


public interface EmployeeDAO {
	
	int addEmployee(Employee employee);
	public Employee getEmployee(int eid);
	public Employee updateEmployee(Employee employee);
	
	public ArrayList<Employee>getEmployeeList(double salary);
	public Employee removeEmployee(int eid);

}
