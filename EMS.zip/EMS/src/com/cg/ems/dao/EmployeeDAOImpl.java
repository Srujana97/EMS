package com.cg.ems.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

import com.cg.ems.dto.Employee;


public class EmployeeDAOImpl implements EmployeeDAO{

	Map<Integer, Employee> employeeMap;
	public EmployeeDAOImpl() {
		// TODO Auto-generated constructor stub
		employeeMap = DataStore.createCollection();
	}
	@Override
	public int addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		int empid = (int) (1000*Math.random());
		employee.setEmpId(empid);
		employeeMap.put(empid,employee);
		Employee e = employeeMap.get(1);
		//System.out.println(e);
		return empid;
	}

	@Override
	public Employee getEmployee(int eid) {
		// TODO Auto-generated method stub
        Employee e = employeeMap.get(eid);
		return e;
	}

	@Override
	public Employee updateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		employeeMap.put(employee.getEmpId(),employee);
		return employee;
	}

	@Override
	public ArrayList<Employee> getEmployeeList(double salary) {
		// TODO Auto-generated method stub
		Collection<Employee> empList = employeeMap.values();
		ArrayList<Employee> employees = new ArrayList<>();
		
		for(Employee e: empList){
			if(e.getSalary()== salary){
				employees.add(e);
			}
		}
		
		return employees;
	}

	@Override
	public Employee removeEmployee(int eid) {
		// TODO Auto-generated method stub
		return employeeMap.remove(eid);
	}

}
