package com.cg.ems.service;

import java.util.ArrayList;

import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;




public interface EmployeeService {
	int addEmployee(Employee employee);
	public Employee getEmployee(int eid);
	public Employee updateEmployee(Employee employee);
	
	public ArrayList<Employee>getEmployeeList(double salary);
	public Employee removeEmployee(int eid);
	
	
	public Employee ValidateDetails(Employee e)throws EmployeeException;
	public boolean validateName(String name) throws EmployeeException;
	//public boolean validateSalary(double salary) throws EmployeeException;
	//public boolean validateDesignation(String designation) throws EmployeeException;
	

}
