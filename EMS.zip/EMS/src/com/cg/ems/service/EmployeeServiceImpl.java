package com.cg.ems.service;

import java.util.ArrayList;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.ems.dto.Employee;
import com.cg.ems.dao.DataStore;
import com.cg.ems.dao.EmployeeDAO;
import com.cg.ems.dao.EmployeeDAOImpl;
import com.cg.ems.exception.EmployeeException;


public class EmployeeServiceImpl implements EmployeeService{
	
	
	
EmployeeDAO dao;
	
	public EmployeeServiceImpl() {
		super();
		dao = new EmployeeDAOImpl();
	}
	@Override
	public int addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		if(employee.getSalary() > 5000 && employee.getSalary() < 20000){
			employee.setInsuranceScheme("Scheme c");
		}
		else if (employee.getSalary() >= 20000 && employee.getSalary() < 40000) {
            // Designation = "Programmer";
			employee.setInsuranceScheme("Scheme b");
        } else if (employee.getSalary() >= 40000) {
            // Designation = "Manager";
        	employee.setInsuranceScheme("Scheme a");
        } else if (employee.getSalary() < 5000) {
            // Designation = "Clerk";
        	employee.setInsuranceScheme("no scheme");
        }
		return dao.addEmployee(employee);
		
	}

	@Override
	public Employee getEmployee(int eid) {
		// TODO Auto-generated method stub
		return dao.getEmployee(eid);
	}

	@Override
	public Employee updateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return dao.updateEmployee(employee);
	}

	@Override
	public ArrayList<Employee> getEmployeeList(double salary) {
		// TODO Auto-generated method stub
		return dao.getEmployeeList(salary);
	}

	@Override
	public Employee removeEmployee(int eid) {
		// TODO Auto-generated method stub
		return dao.removeEmployee(eid);
	}
	@Override
	public Employee ValidateDetails(Employee e) throws EmployeeException {
		// TODO Auto-generated method stub
		if(validateName(e.getName()))// &&
				// validateSalary(e.getSalary()) && 
						// validateDesignation(e.getDesignation()) )
		return e;
		else
	return null;
	
	}
	@Override
	public boolean validateName(String name) throws EmployeeException {
		// TODO Auto-generated method stub
		if(name==null)
			throw new EmployeeException("name can not be null");
		Pattern pat = Pattern.compile("[A-Z][a-z]{3,12}");
		Matcher mat= pat.matcher(name);
		return mat.matches();
		
	}
	//@Override
	/*public boolean validateSalary(double salary) throws EmployeeException {
		// TODO Auto-generated method stub
		Pattern pat = Pattern.compile("[0-9]{10}");
		Matcher mat= pat.matcher(salary);
		return mat.matches();

		return false;
	}*
	@Override
	public boolean validateEmail(String email) throws EmployeeException {
		// TODO Auto-generated method stub
		return false;
	}*/
	

}
