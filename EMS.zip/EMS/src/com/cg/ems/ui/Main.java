package com.cg.ems.ui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import com.cg.ems.dto.Employee;
import com.cg.ems.service.EmployeeService;
import com.cg.ems.service.EmployeeServiceImpl;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		EmployeeService service = new EmployeeServiceImpl();
		
		Scanner sc = new Scanner(System.in);
		int ch = 0;
		do{
		System.out.println("\nEnter Choice :\n");
		System.out.println("1. Add Employee :\n");
		System.out.println("2. Display Employee Details :\n");
		System.out.println("3. Update Employee:\n");
		System.out.println("4. Remove Employee:\n");
		System.out.println("5. Display Employee:\n");
		System.out.println("6. Exit\n");
	    ch = sc.nextInt();
		switch(ch) {
		
		
		
		case 1:
			
		System.out.println("Enter name : ");
		String name = sc.next();
		
		System.out.println("Enter salary : ");
		double salary = sc.nextDouble();
		
		System.out.println("Enter Designation : ");
		String designation = sc.next();
		
		
		Employee employee = new Employee();
		employee.setName(name);
		employee.setSalary(salary);
		employee.setDesignation(designation);
		
		int eid = service.addEmployee(employee);
		System.out.println("Employee record added.."+eid);
		break;
		
		case 2:
			
			System.out.println("Enter Employee no: \n");
			eid = sc.nextInt();
			employee = service.getEmployee(eid);
			if(employee == null)
				System.err.println("Record not found");
			else{
			System.out.println(employee.getName());
			System.out.println(employee.getSalary());
			System.out.println(employee.getDesignation());
			System.out.println(employee.getInsuranceScheme());
			}
			break;
			
		case 3:
			System.out.println("Enter Emp no. : ");
			eid = sc.nextInt();
			employee = service.getEmployee(eid);
			if(employee == null)
				System.err.println("Record not Found");
			else{
				System.out.println("Enter new salary:");
				double s = sc.nextDouble();
				employee.setSalary(s);
				employee = service.updateEmployee(employee);
				System.out.println("Record Updated: ");
				System.out.println(employee.getName());
				System.out.println(employee.getSalary());
				
			}
			break;
			
		case 4:
			System.out.println("Enter Employee Id: \n");
			eid = sc.nextInt();
			employee = service.removeEmployee(eid);
			if(employee == null)
				System.err.println("Record not Found");
			else{
				employee = service.removeEmployee(eid);
				System.out.println("Record deleted: ");
				
				
			}
			break;
			
		case 5:
			System.out.println("Enter Salary : ");
			salary = sc.nextDouble();
			ArrayList<Employee> list = service.getEmployeeList(salary);
			if(list.size() == 0)
				System.out.println("No Employee Enrolled to this course");
			else{
				for(Employee e: list){
				
				//Iterator<Student> itr = studList.iterator();
				//while(itr.hasNext()){
					
					System.out.println(e.getName()+ " "+e.getSalary());
				}
			}
			break;
		

		}//switch
		
		
	}while(ch!=6);

}
}
